import{a2 as e,$ as a,B as o,C as n}from"./BbZHNIt9.js";const i=e(l=>{if(!localStorage.getItem("auth-token"))return a(()=>{const t=o("loginModal");t.value=!0}),n("/")});export{i as default};
