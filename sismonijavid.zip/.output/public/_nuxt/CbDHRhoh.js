import"./CXi9IBJW.js";const p=""+new URL("logo.BGpC-RES.png",import.meta.url).href;export{p as _};
