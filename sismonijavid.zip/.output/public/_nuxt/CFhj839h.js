import{a1 as e,Z as a,A as o,B as n}from"./CXi9IBJW.js";const i=e(l=>{if(!localStorage.getItem("auth-token"))return a(()=>{const t=o("loginModal");t.value=!0}),n("/")});export{i as default};
