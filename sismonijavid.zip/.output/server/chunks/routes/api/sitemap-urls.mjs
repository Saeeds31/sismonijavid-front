import { c as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const sitemapUrls = defineEventHandler(async () => {
  var _a;
  try {
    const data = await $fetch("https://api.sismonijavid.ir/api/v1/sitemap-urls");
    return (_a = data == null ? void 0 : data.data) != null ? _a : [];
  } catch (error) {
    console.error("\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0644\u06CC\u0633\u062A \u0633\u0627\u06CC\u062A\u200C\u0645\u067E:", error);
    return [];
  }
});

export { sitemapUrls as default };
//# sourceMappingURL=sitemap-urls.mjs.map
