<template>
    <div class="loader"></div>
</template>
<style scoped>
.loader {
    width: 6px;
    aspect-ratio: 1;
    border-radius: 50%;
    animation: l5 1s infinite linear alternate;
}

@keyframes l5 {
    0% {
        box-shadow: 8px 0 #000, -8px 0 #0002;
        background: #000
    }

    33% {
        box-shadow: 8px 0 #000, -8px 0 #0002;
        background: #0002
    }

    66% {
        box-shadow: 8px 0 #0002, -8px 0 #000;
        background: #0002
    }

    100% {
        box-shadow: 8px 0 #0002, -8px 0 #000;
        background: #000
    }
}
</style>