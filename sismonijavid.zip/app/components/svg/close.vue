<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M9.17001 14.8299L14.83 9.16992" stroke="#292D32" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M14.83 14.8299L9.17001 9.16992" stroke="#292D32" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="#292D32"
            stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>