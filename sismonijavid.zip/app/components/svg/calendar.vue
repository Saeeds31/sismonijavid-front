<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d="M6.66602 1.66602V4.16602" stroke="#72B742" stroke-miterlimit="10" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M13.334 1.66602V4.16602" stroke="#72B742" stroke-miterlimit="10" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M2.91602 7.57422H17.0827" stroke="#72B742" stroke-miterlimit="10" stroke-linecap="round"
            stroke-linejoin="round" />
        <path
            d="M17.5 7.08268V14.166C17.5 16.666 16.25 18.3327 13.3333 18.3327H6.66667C3.75 18.3327 2.5 16.666 2.5 14.166V7.08268C2.5 4.58268 3.75 2.91602 6.66667 2.91602H13.3333C16.25 2.91602 17.5 4.58268 17.5 7.08268Z"
            stroke="#72B742" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M13.0781 11.4167H13.0856" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M13.0781 13.9167H13.0856" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M9.99632 11.4167H10.0038" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M9.99632 13.9167H10.0038" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M6.91185 11.4167H6.91933" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M6.91185 13.9167H6.91933" stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>