<template>
  <main>
    <div v-if="pending" class="min-h-screen flex flex-col items-center justify-center">
      <div class="w-full max-w-7xl mx-auto px-4 space-y-12 animate-pulse">
        <div class="h-96 bg-gray-200 rounded-inner" />
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div v-for="n in 4" :key="n" class="h-64 bg-gray-200 rounded-inner" />
        </div>
        <div class="h-48 bg-gray-200 rounded-inner" />
      </div>
    </div>

    <div v-else-if="error" class="min-h-screen flex items-center justify-center text-center py-20">
      <div>
        <p class="text-red-500 text-xl mb-6">خطایی در بارگذاری صفحه رخ داد</p>
        <button @click="refresh" class="btn">دوباره تلاش کن</button>
      </div>
    </div>

    <div v-else-if="home" class="space-y-10">
      <HomeSlider :sliders="home.sliders" />
      <HomeNewProductsList :new_products="home.is_rechargeables" />
      <HomeCategories :categories="home.selected_categories" />
      <!-- <HomeBanners v-if="home.banners?.after_discount?.length" :banners="home.banners.after_discount" /> -->

      <!-- محصولات جدید با دیتا از products و فیلتر از shop-filters -->
      <HomeNewProducts :selectedCategoryList="home.selectedCategoryList" v-if="home && home.selectedCategoryList" />

      <!-- <HomeBannerTriple :items="banners" /> -->
      <!-- <HomeVotedRestockSection v-if="home && home.is_rechargeables && home.is_rechargeables.length"
        :products="home.is_rechargeables" /> -->

      <!-- <HomeBannerTriple v-if="bannersBeforeAbout.length" :items="bannersBeforeAbout" /> -->

      <!-- <HomeBanners v-if="home.banners?.after_new_product?.length" :banners="home.banners.after_new_product" /> -->
      <!-- <HomeBanners v-if="home.banners?.before_blog?.length" :banners="home.banners.before_blog" /> -->
      <AboutHomeStor />
      <AboutFAQSection />
      />
      <!-- <HomeArticles :list="home.blogs" /> -->
    </div>

    <div v-else class="min-h-screen flex items-center justify-center text-center py-20 text-muted text-xl">
      محتوای صفحه اصلی در دسترس نیست.
    </div>
  </main>
</template>

<script setup>
import { computed, ref, onMounted } from "vue";
import { useHomeStore } from "~/store/home";
import { useApi } from "@/composables/api/useApi";
import { usePageLoading } from "@/composables/usePageLoading";

const homeStore = useHomeStore();
const { getHome } = useApi();
const { loadPageWithBase } = usePageLoading();

// وضعیت‌ها
const pending = ref(true);
const error = ref(null);

// داده‌های محصولات


try {
  await loadPageWithBase(
    [
      async () => {
        if (homeStore.home) return homeStore.home;
        const response = await getHome();
        const fetchedData = response?.data?.data || response?.data;
        homeStore.setHome(fetchedData);
        return fetchedData;
      },
    ],
    "در حال بارگذاری صفحه اصلی...",
  );
} catch (err) {
  error.value = err;
  console.error("خطا در بارگذاری صفحه اصلی:", err);
} finally {
  pending.value = false;
}

const home = computed(() => homeStore.home);

const topDiscountedProducts = computed(
  () => home.value?.top_discounted_products || [],
);

const refresh = async () => {
  pending.value = true;
  error.value = null;
  try {
    await loadPageWithBase(
      [
        async () => {
          if (homeStore.isLoaded) return homeStore.home
          const response = await getHome();
          const fetchedData = response?.data?.data || response?.data;
          homeStore.setHome(fetchedData);
          return fetchedData;
        },

      ],
      "در حال بارگذاری مجدد...",
    );
  } catch (err) {
    error.value = err;
  } finally {
    pending.value = false;
  }
};

const bannerAssets = {
  1: {
    image: "/banner/banner-sleep.svg",
    bgFrom: "#0288D1",
    bgTo: "#006FAD",
    button: "مشاهده و خرید",
  },
  2: {
    image: "/banner/banner-men.svg",
    bgFrom: "#009432",
    bgTo: "#006D26",
    button: "مشاهده و خرید",
  },
  3: {
    image: "/banner/banner-fantasy.svg",
    bgFrom: "#00C9A7",
    bgTo: "#00A98F",
    button: "مشاهده و خرید",
  },
  4: {
    image: "/banner/banner-top.svg",
    bgFrom: "#029C83",
    bgTo: "#018A73",
    button: "مشاهده و خرید",
  },
  5: {
    image: "/banner/banner-bra.svg",
    bgFrom: "#8CA61C",
    bgTo: "#6D8C1A",
    button: "مشاهده و خرید",
  },
  6: {
    image: "/banner/banner-socks.svg",
    bgFrom: "#7A0D8C",
    bgTo: "#A030C7",
    button: "مشاهده و خرید",
  },
};

const banners = computed(() => {
  const apiItems = home.value?.banners?.after_products || [];
  return apiItems.map((b) => {
    const asset = bannerAssets[b.id] || {};
    return {
      id: b.id,
      title: b.title,
      link: b.link,
      image: b.image_desktop || asset.image,
      bgFrom: asset.bgFrom || "#1f2937",
      bgTo: asset.bgTo || "#111827",
      button: asset.button || "مشاهده",
    };
  });
});

const bannersBeforeAbout = computed(() => {
  const apiItems = home.value?.banners?.before_about || [];
  return apiItems.map((b) => {
    const asset = bannerAssets[b.id] || {};
    return {
      id: b.id,
      title: b.title,
      link: b.link,
      image: b.image_desktop || asset.image,
      bgFrom: asset.bgFrom || "#1f2937",
      bgTo: asset.bgTo || "#111827",
      button: asset.button || "مشاهده",
    };
  });
});
function handlerLastPosition() {

  if (localStorage.getItem("lastPosition")) {
    window.scrollTo({
      top: parseFloat(localStorage.getItem("lastPosition")),
      behavior: 'smooth'
    });
    let btn = document.getElementById(`buttonHomeCategory${localStorage.getItem("activeTab")}`)
    console.log(btn, `buttonHomeCategory${localStorage.getItem("activeTab")}`);

    if (btn) {
      btn.click()
    }
    setTimeout(() => {
      localStorage.removeItem("activeTab");
      localStorage.removeItem("lastPosition");
    }, 500);
  }
}
let timer;
onMounted(() => {
  timer = setInterval(() => {
    console.log("home", home.value);
    if (home.value) {
      setTimeout(() => {
        handlerLastPosition();
      }, 2000);
      clearInterval(timer)
    }
  }, 500)
})
useSeoMeta({
  title: 'سیسمونی جاوید | فروشگاه اینترنتی لوازم سیسمونی و نوزاد در گرگان',
  description: 'خرید آنلاین سیسمونی، لباس نوزاد، لوازم ایمنی و اسباب‌بازی از فروشگاه سیسمونی جاوید. ارسال به سراسر کشور. مراجعه حضوری: گرگان، خیابان سرخواجه، مجتمع آفتاب.',
  ogTitle: 'سیسمونی جاوید | فروشگاه تخصصی لوازم نوزاد',
  ogDescription: 'مجموعه‌ای کامل از بهترین برندهای سیسمونی و لوازم نوزاد با ضمانت اصالت کالا.',
  ogImage: 'https://sismonijavid.ir/_nuxt/logo.BGpC-RES.png', // آدرس یک تصویر شاخص از لوگو یا فروشگاه
  ogUrl: 'https://sismonijavid.ir',
  ogType: 'website',
  ogLocale: 'fa_IR',
  twitterCard: 'summary_large_image',
  robots: 'index, follow',
})

useHead({
  link: [{ rel: 'canonical', href: 'https://sismonijavid.ir' }],
  script: [
    {
      type: 'application/ld+json',
      key: 'home-jsonld',
      innerHTML: JSON.stringify([
        {
          '@context': 'https://schema.org',
          '@type': 'OnlineStore',
          name: 'سیسمونی جاوید',
          url: 'https://sismonijavid.ir',
          logo: 'https://sismonijavid.ir/logo.png', // مسیر لوگوی سایت
          description: 'فروشگاه اینترنتی سیسمونی جاوید، عرضه‌کننده لوازم نوزاد، سیسمونی و اسباب‌بازی در گرگان و سراسر ایران.',
          telephone: '+989375015769', // فرمت بین‌المللی شماره تماس
          address: {
            '@type': 'PostalAddress',
            streetAddress: 'خیابان سرخواجه، مجتمع آفتاب، طبقه همکف',
            addressLocality: 'گرگان',
            addressRegion: 'گلستان',
            addressCountry: 'IR',
          },
          contactPoint: {
            '@type': 'ContactPoint',
            telephone: '+989375015769',
            contactType: 'customer service',
            areaServed: 'IR',
            availableLanguage: 'Persian',
          },
        },
        {
          '@context': 'https://schema.org',
          '@type': 'WebSite',
          name: 'سیسمونی جاوید',
          url: 'https://sismonijavid.ir',
          potentialAction: {
            '@type': 'SearchAction',
            target: {
              '@type': 'EntryPoint',
              urlTemplate: 'https://sismonijavid.ir/search?q={search_term_string}',
            },
            'query-input': 'required name=search_term_string',
          },
        },
      ]),
    },
  ],
})
</script>

<style scoped>
.animate-pulse {
  animation: pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

@keyframes pulse {

  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.5;
  }
}
</style>
